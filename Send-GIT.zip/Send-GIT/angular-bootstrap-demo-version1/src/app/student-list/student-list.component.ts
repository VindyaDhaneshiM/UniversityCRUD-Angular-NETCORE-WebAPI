import { Component, OnInit,ViewChild } from '@angular/core';
import { StudentService } from '../student.service';
import { Student} from 'src/app/student.model';
import { ToastrService } from 'ngx-toastr';
import { Router } from '@angular/router';
import { StudentComponent } from 'src/app/student/student.component';
import { UpdatestudentComponent } from 'src/app/updatestudent/updatestudent.component';

@Component({
  selector: 'app-student-list',
  templateUrl: './student-list.component.html',
  styleUrls: ['./student-list.component.css']
})
export class StudentListComponent implements OnInit {
  students;
  selectedStudent;
  stulist: Student[];
  dataavailbale: Boolean = false;
  tempstu: Student
  alldatas: object;
  constructor(public studentService:StudentService,private toastr: ToastrService,private route: Router) { }

  ngOnInit() {
    this.studentService.getStudent().subscribe(res=> {
      this.alldatas = res;
      console.log(this.alldatas);
       });
    this.studentService.refreshList();
  
  }
 // @ViewChild('lecadd') addcomponent: LecturerComponent
  // @ViewChild('Lecedit') editcomponent: UpdatelecturerComponent

  public selectStudent(student){
    this.selectedStudent = student ;
  }

  populateForm(stu:Student){
    this.studentService.formData = Object.assign({},stu);

}
onDelete(id:number)
 {
   if(confirm("Are you sure to delete this record?")){
   this.studentService.deleteStudent(id).subscribe(res=>{
     this.studentService.refreshList();
       this.toastr.warning('Deleted Sucessfully','Swinburne University')
   });}
 }
}