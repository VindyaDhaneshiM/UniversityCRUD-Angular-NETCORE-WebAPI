import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-updatestudent',
  templateUrl: './updatestudent.component.html',
  styleUrls: ['./updatestudent.component.css']
})
export class UpdatestudentComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
