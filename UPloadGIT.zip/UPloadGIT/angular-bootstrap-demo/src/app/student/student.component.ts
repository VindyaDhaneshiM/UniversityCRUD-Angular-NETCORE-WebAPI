import { Component, OnInit } from '@angular/core';
import { StudentService } from '../student.service';
import { NgForm, FormGroup } from '@angular/forms';
import { ToastrService } from 'ngx-toastr';
import { Input, ViewChild, ElementRef, EventEmitter, Output } from '@angular/core';
import { Student } from '../student.model';
import {  ChangeDetectorRef } from '@angular/core';
import { FormBuilder, FormArray, Validators } from "@angular/forms";
import { Router } from  '@angular/router';
// import { ValidatePassword } from "./must-match/validate-password";
@Component({
  selector: 'app-student',
  templateUrl: './student.component.html',
  styleUrls: ['./student.component.css']
})
export class StudentComponent implements OnInit {
  @Input()  cleardata: boolean = false;
  @Output() nameEvent = new EventEmitter<string>();
  objtstustu:Student;
  @Input() objstu :Student=new Student();;
  // @ViewChild('closeBtn') cb: ElementRef;
 // student : {id,fname, lname,dob,email,gender, address} = {id :null, fname:" ", lname :"",dob:"",email:"",gender:"", address:""};
 
  constructor(private service: StudentService,private toastr: ToastrService,private router: Router, private formBuilder: FormBuilder) { }

  submitted = false;
  studentForm: FormGroup;
  isSubmitted  =  false;
  ngOnInit() {
    this.studentForm  =  this.formBuilder.group({
      firstName: ['', [Validators.required, Validators.minLength(2), Validators.pattern('^[_A-z0-9]*((-|\s)*[_A-z0-9])*$')]],
      lastName: ['', [Validators.required, Validators.minLength(2), Validators.pattern('^[_A-z0-9]*((-|\s)*[_A-z0-9])*$')]],
      dateofBirth: ['', [Validators.required, Validators.maxLength(10), Validators.pattern('^(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?!.*\s).{6,12}$')]],
      contactEmail: ['', [Validators.required, Validators.pattern('[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,3}$')]],
      Gender: ['male'],
      contactAddress: ['', [Validators.required, Validators.minLength(2), Validators.pattern('^[_A-z0-9]*((-|\s)*[_A-z0-9])*$')]],
      
  });
    this.resetForm();
  }

  get formControls() { return this.studentForm.controls; }

  resetForm(form? : NgForm){
    if(form != null)
       form.resetForm();
       this.service.formData = {
        StudentID: null,
        FirstName:'',
        LastName:'',
        DateofBirth:'',
        ContactEmail:'',
        Gender:'',
        ContactAddress:''
       }
       }
//   createContact(){
//     console.log(this.student);
//     this.dataService.createStudent(this.student);
//     this.student = {id :null, fname:" ", lname :"",dob:"",email:"",gender:"", address:""};
// }

onSubmit(form : NgForm) {
  // if(form.value.LecturerID==null)
  console.log(this.studentForm.value);
    this.isSubmitted = true;
    if(this.studentForm.invalid){
      return;
    }
  this.insertRecord(form);
  // else
  // this.updateRecord(form);
}

insertRecord(form : NgForm){
  this.service.postStudent(form.value).subscribe(res=> {
  this.toastr.success('Inserted Sucessfully','Swinburne Register')
 this.resetForm(form);
 this.service.refreshList();
  });
 }
 Register(stuadd:NgForm){  
   
  this.objtstustu=new Student();
  this.objtstustu.FirstName=stuadd.value.firstName;
  this.objtstustu.LastName=stuadd.value.lastName;
  this.objtstustu.DateofBirth=stuadd.value.dateofBirth;
  this.objtstustu.ContactEmail=stuadd.value.contactEmail;
  this.objtstustu.Gender=stuadd.value.gender;
  this.objtstustu.ContactAddress=stuadd.value.contactAddress;
  

  
this.service.AddStudent(this.objtstustu).subscribe(res=>{
  alert("Student Added successfully");
  // this.TakeHome();
  // this.lecadd.objtleclec.FirstName = ""
}
)}

updateRecord(form:NgForm){
  this.service.putStudent(form.value).subscribe(res=> {
    this.toastr.warning('Updated Sucessfully','Swinburn Register')
    this.resetForm(form);
    this.service.refreshList();
     });

}

}
