import { Injectable } from '@angular/core';
import {HttpClient } from "@angular/common/http";
import { Course } from './course.model';
import { CourseListComponent } from './course-list/course-list.component';
import {  HttpParams, HttpHeaders } from '@angular/common/http';
import { ConfigComponent } from './config/config.component'; 
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class CourseService {
  formData : Course;
  list : Course[];
  readonly rootURL="https://localhost:5001/api"
  courses:Observable<Course[]>
  newcourse:Course;
  // courses = [
  //   {id: 1, cname: "Bsc Hons in Computer Science",cduration:"4 Years" , coursetype: "Full Time",faculty:"Computer Science",prerequisites:"Certificate in Computing"},
  //   {id: 2, cname: "Bsc Hons in Software Engineering",cduration:"4 Years" , coursetype: "Full Time",faculty:"Computer Science",prerequisites:"Certificate in Computing"},

  //   {id: 3, cname: "Bsc  Hons in Information Technology",cduration:"4 Years" , coursetype: "Full Time",faculty:"Information Technology",prerequisites:"Certificate in Computing"},
  //   {id: 4, cname: "Msc in Computer Science",cduration:"2 Years" , coursetype: "Part Time",faculty:"Applied Science",prerequisites:"Bsc Degree in Computing"}
  // ];

  // public getCourses():Array<{id,cname, cduration,coursetype,faculty,prerequisites}>{
  //   return this.courses;
  // }

  // public createCourse(course: {id,cname, cduration,coursetype,faculty,prerequisites}){
  //   this.courses.push(course);
  // }
// ---
  constructor(private http:HttpClient) { }


  postCourse( formData : Course){
    return this.http.post(this.rootURL+'/Course',formData)
  }
  
  refreshList(){
  this.http.get(this.rootURL+'/Course')
  .toPromise().then(res => this.list = res as Course[]);
  }
  
  putCourse(formData:Course){
  return this.http.put(this.rootURL+'/Course/'+formData.CourseID,formData);
  }
  deleteCourse(id : number)
  {
  return this.http.delete(this.rootURL+'/Course/'+id);
  }
  getCourse(){
    return this.http.get(this.rootURL+'/Course');
  }
  
  AddCourse(crs: Course) {

    const headers = new HttpHeaders().set('content-type', 'application/json');
    var body = {
      CourseName:crs.CourseName,CourseDuration:crs.CourseDuration, CourseType:crs.CourseType,FacultyOffer:crs.FacultyOffer,CoursePrerequisites:crs.CoursePrerequisites  }
    console.log(this.rootURL);

    return this.http.post< Course>(this.rootURL + '/Course', body, { headers });

  }

}
