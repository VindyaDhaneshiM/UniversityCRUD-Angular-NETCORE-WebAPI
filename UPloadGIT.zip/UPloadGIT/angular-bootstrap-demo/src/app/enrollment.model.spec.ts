import { Enrollment } from './enrollment.model';

describe('Enrollment', () => {
  it('should create an instance', () => {
    expect(new Enrollment()).toBeTruthy();
  });
});
