import { Component, OnInit } from '@angular/core';
import { StudentService } from '../student.service';
import { NgForm } from '@angular/forms';
import { ToastrService } from 'ngx-toastr';
import { Input, ViewChild, ElementRef, EventEmitter, Output } from '@angular/core';
import { Student } from '../student.model';
@Component({
  selector: 'app-student',
  templateUrl: './student.component.html',
  styleUrls: ['./student.component.css']
})
export class StudentComponent implements OnInit {
  @Input()  cleardata: boolean = false;
  @Output() nameEvent = new EventEmitter<string>();
  objtstustu:Student;
  @Input() objstu :Student=new Student();;
  // @ViewChild('closeBtn') cb: ElementRef;
 // student : {id,fname, lname,dob,email,gender, address} = {id :null, fname:" ", lname :"",dob:"",email:"",gender:"", address:""};
 
  constructor(private service: StudentService,private toastr: ToastrService) { }

  ngOnInit() {
    this.resetForm();
  }

  resetForm(form? : NgForm){
    if(form != null)
       form.resetForm();
       this.service.formData = {
        StudentID: null,
        FirstName:'',
        LastName:'',
        DateofBirth:'',
        ContactEmail:'',
        Gender:'',
        ContactAddress:''
       }
       }
//   createContact(){
//     console.log(this.student);
//     this.dataService.createStudent(this.student);
//     this.student = {id :null, fname:" ", lname :"",dob:"",email:"",gender:"", address:""};
// }

onSubmit(form : NgForm) {
  // if(form.value.LecturerID==null)
  this.insertRecord(form);
  // else
  // this.updateRecord(form);
}

insertRecord(form : NgForm){
  this.service.postStudent(form.value).subscribe(res=> {
  this.toastr.success('Inserted Sucessfully','Swinburne Register')
 this.resetForm(form);
 this.service.refreshList();
  });
 }
 Register(stuadd:NgForm){  
   
  this.objtstustu=new Student();
  this.objtstustu.FirstName=stuadd.value.firstName;
  this.objtstustu.LastName=stuadd.value.lastName;
  this.objtstustu.DateofBirth=stuadd.value.dateofBirth;
  this.objtstustu.ContactEmail=stuadd.value.contactEmail;
  this.objtstustu.Gender=stuadd.value.gender;
  this.objtstustu.ContactAddress=stuadd.value.contactAddress;
  

  
this.service.AddStudent(this.objtstustu).subscribe(res=>{
  alert("Student Added successfully");
  // this.TakeHome();
  // this.lecadd.objtleclec.FirstName = ""
}
)}

updateRecord(form:NgForm){
  this.service.putStudent(form.value).subscribe(res=> {
    this.toastr.warning('Updated Sucessfully','Swinburn Register')
    this.resetForm(form);
    this.service.refreshList();
     });

}

}
