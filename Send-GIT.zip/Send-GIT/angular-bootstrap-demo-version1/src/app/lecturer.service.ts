import { Injectable } from '@angular/core';
import {HttpClient } from "@angular/common/http";
import { Lecturer } from './lecturer.model';
import {  HttpParams, HttpHeaders } from '@angular/common/http';
import { ConfigComponent } from './config/config.component'; 
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class LecturerService {
  formData : Lecturer;
  list : Lecturer[];
  readonly rootURL="https://localhost:5001/api"
  lecturers:Observable<Lecturer[]>
  newlecturer:Lecturer;
  // lecturers = [
  //   {id: 1, fname: "Saman",lname:"Perera" , dob: "10-03-1990",doj:"20-07-2019",email:"sam@gmail.com", gender: "Male",address:"No 5 Temple Road Colombo",category:"Senior Lecturer",contract:"Permanant",qualification:"Phd Degree"},
  //   {id: 2, fname: "Nimal",lname:"Silva" , dob: "20-05-1995",doj:"28-05-2019",email:"nim@gmail.com", gender: "Male",address:"No 7 Flowers Road Colombo",category:" Lecturer",contract:"Probationary",qualification:"Msc Degree"},

  //   {id: 3, fname: "Kusum",lname:"Senarathna" , dob: "17-04-1992",doj:"10-09-2019",email:"kus@gmail.com", gender: "Female",address:"No 15 StAnthoney Road Kadana",category:" Assistant Lecturer",contract:"Part Time",qualification:"Bsc Degree"},
  //   {id: 4, fname: "Ruwan",lname:"Gunasekara" , dob: "22-03-1990",doj:"217-07-2019",email:"run@gmail.com", gender: "Male",address:"No 5 Temple Road Colombo",category:"  Lecturer",contract:"Part Time",qualification:"Msc Degree"}
  // ];

  // public getLecturers():Array<{id,fname, lname,dob,doj,email,gender, address,category,contract,qualification}>{
  //   return this.lecturers;
  // }

  // public createLecturer(lecturer: {id,fname, lname,dob,doj,email,gender, address,category,contract,qualification}){
  //   this.lecturers.push(lecturer);
  // }

// ---
   constructor(private http:HttpClient) { }

   postLecturer( formData : Lecturer){
     return this.http.post(this.rootURL+'/lecturer',formData)
   }
 
   refreshList(){
  this.http.get(this.rootURL+'/lecturer')
   .toPromise().then(res => this.list = res as Lecturer[]);
   console.log(this.list)
   }
 
  
   putLecturer(formData:Lecturer){
   return this.http.put(this.rootURL+'/lecturer/'+formData.LecturerID,formData);
   }

   deleteLecturer(id : number)
   {
   return this.http.delete(this.rootURL+'/lecturer/'+id);
   }


   getLecturer(){
     return this.http.get(this.rootURL+'/lecturer');
   }
   getLecturer2() {
    return this.http.get<Lecturer[]>(this.rootURL + 'Lecturers');
  }
   AddLecturer(lec: Lecturer) {

    const headers = new HttpHeaders().set('content-type', 'application/json');
    var body = {
      FirstName: lec.FirstName, LastName: lec.LastName, DateofBirth: lec.DateofBirth, DateofJoin: lec.DateofJoin,ContactEmail:lec.ContactEmail,
      Gender:lec.Gender,ContactAddress:lec.ContactAddress,LecturerCategory:lec.LecturerCategory,LecturerContract:lec.LecturerContract,
      LecturerQualification:lec.LecturerQualification
    }
    console.log(this.rootURL);

    return this.http.post<Lecturer>(this.rootURL + '/lecturer', body, { headers });

  }

  

  

}
  

